import 'package:flutter/widgets.dart';

class L10n {
  static const supported = [Locale('en'), Locale('ar')];
}
