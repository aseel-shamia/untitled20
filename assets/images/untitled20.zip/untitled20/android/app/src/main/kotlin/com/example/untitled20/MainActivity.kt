package com.example.untitled20

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
